# Disable Splash
splash = false

wallpaper {
    monitor = 
    path = WALLPAPER
    fit_mode = cover
}
