#!/bin/bash

VPN_NAME=homevpn

openvpn3 sessions-list | grep -I 'connected' > /dev/null
# 0 on found
exit $?
