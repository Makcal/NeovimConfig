import re

f = open("style.css", 'r+')
s = f.read()
with open('style.css.bkp', 'w') as bf:
    bf.write(s)
ns = re.sub(r'font-size: ?(\d+)px', lambda m: f'font-size: {int(m.group(1))+2}px', s)
f.seek(0)
f.write(ns)
f.close()
